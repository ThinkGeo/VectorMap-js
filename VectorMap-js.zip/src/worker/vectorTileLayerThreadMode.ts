export enum VectorTileLayerThreadMode{
    Default=1,
    SingleThread,
    SingleBackgroundWorker,
    MultiBackgroundWorker
}