export enum GeoBrushType {
    GeoSolidBrush = 0,
    GeoRadialGradientBrush = 1,
    GeoLinearGradientBrush = 2,
    GeoHatchBrush = 3,
    GeoTextureBrush = 4
}