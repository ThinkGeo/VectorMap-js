export interface BrushTypeOptions {
    fillColor?: string;
    fillOpacity?: number;
    radialGradient?: string;
    linearGradient?: string;
    textureFile: string;
    foregroundFill?: string;
    hatchStyle?: string;
}